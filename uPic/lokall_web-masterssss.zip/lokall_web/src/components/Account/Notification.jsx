/* eslint-disable max-len */
import React, { useState, useEffect } from 'react';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import { useRouter } from 'next/router';


import css from '@Assets/sass/custom.sass';

import Loading from '@Components/Base/Loading';
import ViewMore from '@Components/Base/ViewMore';
import AccountAction from '@Actions/account';
import netWork from '@Utils/network';
import Config from '@Config';
import unique from '@Utils/unique';

const useStyles = createUseStyles(({
  root: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
  notification: {
    margin: [0, 0, 36, 0],
    fontSize: 18,
    color: '#f5222d',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    '& svg': {
      marginRight: 8,
    },
  },
  wrapper: {
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: '#ffffff',
    padding: 24,
    boxSizing: 'border-box',
    borderRadius: 7,
  },
  top: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: 12,
    '& a': {
      fontSize: 20,
      color: '#00bd97',
    },
    '& span': {
      color: '#929292',
      fontSize: 14,
    },
  },
  bottom: {
    display: 'flex',
  },
  pic: {
    width: 300,
    flexShrink: 0,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    borderRadius: 7,
  },
  content: {
    padding: [15, 20],
  },
  title: {
    fontSize: 20,
    lineHeight: '28px',
    color: '#333333',
    minHeight: 56,
    marginBottom: 12,
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 2,
  },
  desc: {
    fontSize: 16,
    lineHeight: '21px',
    color: '#5e5f79',
    minHeight: 84,
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 4,
  },
  box: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontSize: 14,
    lineHeight: '17px',
    margin: [14, 0],
    color: '#5e5f79',
  },
  link: {
    marginLeft: '0.5em',
    flex: 1,
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 1,
    color: '#333333',
  },
  line: {
    width: 1,
    height: 14,
    flexShrink: 0,
    backgroundColor: '#333333',
    margin: [0, '1em'],
  },
  '@media screen and (max-width: 768px)': {
    top: {
      flexDirection: 'column',
      '& span': {
        margin: [12, 0],
      },
    },
    pic: {
      width: '100%',
      paddingTop: '54%',
      marginBottom: 24,
    },
    bottom: {
      flexDirection: 'column',
    },
    content: {
      padding: 0,
    },
  },
}), {
  name: 'Account-c',
});

const Notification = () => {
  const classes = useStyles();
  const [page, setPage] = useState(1);
  const dispatch = useDispatch();
  const router = useRouter();
  const { contribute, loading } = useSelector(state => ({
    contribute: state.getIn(['account', 'notification']),
    loading: state.getIn(['account', 'loading']),
  }), shallowEqual);
  const data = unique(contribute.get('data'));
  const currentPage = contribute.get('current_page');
  const lastPage = contribute.get('last_page');
  const pageSize = contribute.get('per_page');
  const topicUpdateCount = contribute.get('topic_update_count');

  useEffect(() => {
    if (page !== 1) {
      dispatch(AccountAction.fetchData({
        type: 'NOTIFICATION',
        page,
        page_size: pageSize,
      }));
    }
  }, [page]);

  const handleChangeCurrentPage = () => {
    if (!loading) {
      setPage(page + 1);
    }
  };

  useEffect(() => () => {
    dispatch(AccountAction.clearData('NOTIFICATION'));
  }, []);

  const handleOnClickReadNotification = id => {
    if (router.query.pageType === 'notification') {
      netWork.post(`${Config.apiBaseUrl}/api/v1/notification/read`, {
        notification_id: id,
      });
    }
  };

  const statusElement = () => {
    if (loading) {
      return <Loading />;
    }
    if (currentPage === lastPage) {
      return null;
    }
    return <ViewMore onClick={() => handleChangeCurrentPage()} />;
  };

  return (
    <>
      <div className={classNames(classes.notification)}>
        <svg
          width='24px'
          height='24px'
          viewBox='0 0 1024 1024'
        >
          <path
            fill='currentColor'
            d='M820.48 800.64c-17.92 0-32-14.08-32-32s14.08-32 32-32c10.24 0 17.92-4.48 19.84-8.96 0.64-1.28 0.64-1.92 0-3.2-7.68-12.16-19.2-16-46.08-23.68-7.68-1.92-16.64-4.48-25.6-7.68-35.2-11.52-58.24-40.32-58.24-72.96V378.88c0-81.92-86.4-147.84-192-147.84S326.4 297.6 326.4 378.88V620.8c0 32.64-23.04 61.44-58.24 72.96-8.96 3.2-17.92 5.76-25.6 7.68-26.24 7.68-38.4 11.52-46.08 23.68-0.64 1.28-0.64 1.92 0 3.2 2.56 4.48 9.6 8.96 19.84 8.96H640c17.92 0 32 14.08 32 32s-14.08 32-32 32H218.24c-32.64 0-61.44-16-76.16-41.6-12.16-21.12-11.52-46.72 1.28-67.84 21.12-33.92 52.48-42.88 83.2-51.84 7.68-1.92 14.72-4.48 23.04-7.04 8.96-3.2 14.08-8.32 14.08-12.16V378.88c0-117.12 114.56-211.84 256-211.84 140.8 0 256 95.36 256 211.84V620.8c0 3.84 5.12 8.96 14.08 12.16 7.68 2.56 15.36 4.48 22.4 7.04 30.72 8.32 62.08 17.28 83.2 51.84 12.8 21.12 13.44 46.08 1.28 67.84-14.72 24.96-43.52 40.96-76.16 40.96zM519.04 969.6c-53.76 0-99.2-38.4-108.16-92.16-2.56-17.28 8.96-33.92 26.24-36.48 17.28-2.56 33.92 8.96 36.48 26.24 3.84 22.4 22.4 38.4 44.8 38.4s41.6-16 44.8-38.4c2.56-17.28 19.2-29.44 36.48-26.24 17.28 2.56 29.44 19.2 26.24 36.48-7.04 53.76-52.48 92.16-106.88 92.16zM543.36 145.28h-48c-17.92 0-32-14.08-32-32s14.08-32 32-32h48c17.92 0 32 14.08 32 32s-14.08 32-32 32z'
          />
        </svg>
        {topicUpdateCount}
         themen wurde aktualisiert
      </div>
      <div className={classNames(css.columns, classes.root)}>
        {!!data && data.map(item => {
          const topicTitle = item.get('topic_title');
          const topicUpdatedTime = item.get('topic_updated_time');
          const createdAt = item.get('created_at');
          const id = item.get('id');
          const title = item.get('title');
          const fromUrl = item.get('from_url');
          const showUrl = item.get('show_url');
          const pic = item.get('pic');
          const description = item.get('description');
          const slug = item.get('slug');
          return (
            <div
              className={classNames(css.column, css['is-full'], classes.item)}
              key={String(id)}
            >
              <div className={classNames(classes.wrapper)}>
                <div className={classNames(classes.top)}>
                  <h3>
                    <a
                      href={`/topics/${slug}`}
                      rel='noopener noreferrer'
                      onClick={() => handleOnClickReadNotification(id)}
                    >
                      {topicTitle}
                    </a>
                  </h3>
                  <span>{topicUpdatedTime}</span>
                </div>
                <div className={classNames(classes.bottom)}>
                  <div className={classNames(classes.pic)} style={{ backgroundImage: `url(${pic})` }} />
                  <div className={classNames(classes.content)}>
                    <h3 className={classNames(classes.title)}>{title}</h3>
                    <p className={classNames(classes.desc)}>{description}</p>
                    <div className={classNames(classes.box)}>
                      Von
                      <a
                        href={fromUrl}
                        target='_blank'
                        rel='noreferrer'
                        className={classNames(classes.link)}
                        onClick={() => handleOnClickReadNotification(id)}
                      >
                        {showUrl}
                      </a>
                      <span className={classNames(classes.line)} />
                      <span className={classNames(classes.time)}>{createdAt}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {statusElement()}
    </>
  );
};

export default Notification;
