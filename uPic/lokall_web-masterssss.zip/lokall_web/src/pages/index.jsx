import React from 'react';
import classNames from 'classnames';
import Head from 'next/head';
import { useSelector, shallowEqual } from 'react-redux';

import HomeCategory from '@Components/Home/Category';
import HomeHotTopics from '@Components/Home/HotTopics';
import LatestShares from '@Components/Home/LatestShares';
import RecommendTopics from '@Components/Home/RecommendTopics';
import HomeAction from '@Actions/home';

import css from '@Assets/sass/custom.sass';

const HomePage = () => {
  const seoData = useSelector(state => state.getIn(['home', 'seoData']), shallowEqual);
  const homeData = useSelector(state => state.getIn(['home', 'data']), shallowEqual);

  const category = homeData.get('category');
  const hotTopic = homeData.get('hot_topic');
  const latestContribute = homeData.get('latest_contribute');
  const recommendTopic = homeData.get('recommend_topic');
  return (
    <>
      <Head>
        <meta
          name='twitter:card'
          content='summary_large_image'
        />
        <meta
          name='twitter:site'
          content={`@${seoData.get('name')}`}
        />
        <meta
          name='twitter:title'
          content={seoData.get('seo_title')}
        />
        <meta
          name='twitter:description'
          content={seoData.get('seo_description')}
        />
        <meta
          name='twitter:image'
          content={seoData.get('seo_pic')}
        />
        <meta
          property='og:url'
          content='https://www.lokall.de'
        />
        <meta
          property='og:title'
          content={seoData.get('seo_title')}
        />
        <meta
          property='og:description'
          content={seoData.get('seo_description')}
        />
        <meta
          property='og:image'
          content={seoData.get('seo_pic')}
        />
        <meta
          property='og:site_name'
          content={seoData.get('name')}
        />
      </Head>
      <section className={classNames(css.section)}>
        <div className={classNames(css.container)}>
          {!!category.size && <HomeCategory data={category} />}
          {!!hotTopic.size && <HomeHotTopics data={hotTopic} />}
          {!!latestContribute.size && <LatestShares data={latestContribute} />}
          {!!recommendTopic.size && <RecommendTopics data={recommendTopic} />}
        </div>
      </section>
    </>
  );
};

HomePage.getInitialProps = async ({ store }) => {
  await store.dispatch(HomeAction.fetchHomeData());
  return store;
};

export default HomePage;
