# lokall.de



```txt
NOTE: 项目运行时必须包含.env 文件且保证所需环境变量 或 在运行环境中注入与.env配置文件中相同环境变量 必须保证环境变量正确性与可用性
```



```bash
# add project package
$ yarn install

# run dev
$ yarn run dev

# build
$ yarn run build

# start
$ yarn run start

```
