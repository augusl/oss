import React from 'react';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import PropTypes from 'prop-types';

const useStyles = createUseStyles(({
  root: {
    width: '100%',
    paddingTop: '54%',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    position: 'relative',
    borderRadius: 7,
    overflow: 'hidden',
  },
  content: {
    height: 88,
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    display: 'flex',
    alignItems: 'flex-end',
    background: 'linear-gradient(180deg, rgba(35, 35, 35, 0) 0%, #000000 100%)',
    padding: [0, 24, 14, 24],
  },
  title: {
    fontSize: 24,
    lineHeight: '29px',
    color: '#ffffff',
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 2,
  },
}), {
  name: 'Topic',
});

const Topic = ({ data }) => {
  const classes = useStyles();
  const slug = data.get('slug');
  const title = data.get('title');
  const pic = data.get('pic');
  return (
    <a href={`/topics/${slug}`} rel='noopener noreferrer'>
      <div
        className={classNames(classes.root)}
        style={{ backgroundImage: `url(${pic})` }}
      >
        <div className={classNames(classes.content)}>
          <h3 className={classNames(classes.title)}>{title}</h3>
        </div>
      </div>
    </a>
  );
};

Topic.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};


export default Topic;
