import React from 'react';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import PropTypes from 'prop-types';

const useStyles = createUseStyles(({
  root: {
    display: 'block',
    backgroundColor: '#ffffff',
    borderRadius: 7,
    height: '100%',
    overflow: 'hidden',
    boxShadow: '0px 2px 10px 0px rgba(0, 0, 0, 0.2)',
  },
  pic: {
    width: '100%',
    paddingTop: '54%',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
  },
  content: {
    padding: [16, 20, 20],
  },
  title: {
    fontSize: 20,
    lineHieght: '28px',
    color: '#333333',
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 1,
    '&:hover': {
      color: 'hsla(168, 100%, 37%, 1)',
    },
  },
  desc: {
    fontSize: 16,
    lineHieght: '21px',
    color: '#666666',
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 3,
    minHeight: 63,
    marginTop: 14,
  },
}), {
  name: 'Topic',
});

const Topic = ({ data }) => {
  const classes = useStyles();
  const slug = data.get('slug');
  const title = data.get('title');
  const pic = data.get('pic');
  const description = data.get('description');
  return (
    <a href={`/topics/${slug}`} rel='noopener noreferrer' className={classNames(classes.root)}>
      <div
        className={classNames(classes.pic)}
        style={{ backgroundImage: `url(${pic})` }}
      />
      <div className={classNames(classes.content)}>
        <h3 className={classNames(classes.title)}>{title}</h3>
        <p className={classNames(classes.desc)}>{description}</p>
      </div>
    </a>
  );
};

Topic.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};


export default Topic;
