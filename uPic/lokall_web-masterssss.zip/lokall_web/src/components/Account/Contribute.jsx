import React, { useState, useEffect } from 'react';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';

import css from '@Assets/sass/custom.sass';

import UiAction from '@Actions/ui';
import Loading from '@Components/Base/Loading';
import ViewMore from '@Components/Base/ViewMore';
import Share from '@Components/Base/Share';
import AccountAction from '@Actions/account';
import unique from '@Utils/unique';

const useStyles = createUseStyles(({
  root: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
  control: {
    display: 'block',
    margin: [0, 'auto', 36],
  },
}), {
  name: 'Account-Topics',
});

const Contribute = () => {
  const classes = useStyles();
  const [page, setPage] = useState(1);
  const dispatch = useDispatch();
  const { contribute, loading } = useSelector(state => ({
    contribute: state.getIn(['account', 'contribute']),
    loading: state.getIn(['account', 'loading']),
  }), shallowEqual);
  const data = unique(contribute.get('data'));
  const currentPage = contribute.get('current_page');
  const lastPage = contribute.get('last_page');
  const pageSize = contribute.get('per_page');

  useEffect(() => {
    if (page !== 1) {
      dispatch(AccountAction.fetchData({
        type: 'CONTRIBUTE',
        page,
        page_size: pageSize,
      }));
    }
  }, [page]);

  const handleChangeCurrentPage = () => {
    if (!loading) {
      setPage(page + 1);
    }
  };

  useEffect(() => () => {
    dispatch(AccountAction.clearData('CONTRIBUTE'));
  }, []);

  const statusElement = () => {
    if (loading) {
      return <Loading />;
    }
    if (currentPage === lastPage) {
      return null;
    }
    return <ViewMore onClick={() => handleChangeCurrentPage()} />;
  };

  const showAddContributeModal = () => {
    dispatch(UiAction.showModal('contribute'));
  };

  return (
    <>
      <button
        type='button'
        className={classNames(css.button, css['is-primary'], classes.control)}
        onClick={showAddContributeModal}
      >
        Teilen hinzufügen
      </button>
      <div className={classNames(css.columns, classes.root)}>
        {!!data && data.map(item => (
          <div
            className={classNames(css.column, css['is-one-third-desktop'], css['is-half-tablet'], classes.item)}
            key={String(item.get('id'))}
          >
            <Share data={item} />
          </div>
        ))}
      </div>
      {statusElement()}
    </>
  );
};

export default Contribute;
