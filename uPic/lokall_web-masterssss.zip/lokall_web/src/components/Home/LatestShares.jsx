import React from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import PropTypes from 'prop-types';

import ModuleTitle from '@Components/Base/ModuleTitle';
import css from '@Assets/sass/custom.sass';
import ShareItem from './Share';


const useStyles = createUseStyles(({
  root: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
}), {
  name: 'LatestShares',
});

const LatestShares = ({ data }) => {
  const classes = useStyles();
  return (
    <>
      <ModuleTitle
        src={require('../../assets/images/share-icon@2x.png')}
        text='Neuestes Teilen'
      />
      <div className={classNames(classes.root, css.columns)}>
        {!!data && data.map(item => (
          <div
            className={classNames(css.column, css['is-one-third-desktop'], css['is-half-tablet'], classes.item)}
            key={item.get('id')}
          >
            <ShareItem data={item} />
          </div>
        ))}
      </div>
    </>
  );
};

LatestShares.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};

export default LatestShares;
