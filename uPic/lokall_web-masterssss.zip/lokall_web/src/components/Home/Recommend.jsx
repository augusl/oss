import React from 'react';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import PropTypes from 'prop-types';

const useStyles = createUseStyles(({
  root: {
    width: '100%',
    paddingTop: '54%',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    borderRadius: 7,
  },
  title: {
    fontSize: 20,
    lineHeight: '28px',
    color: '#333333',
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 1,
    marginTop: 16,
    fontWeight: 700,
  },
}), {
  name: 'Recommend',
});

const Recommend = ({ data }) => {
  const classes = useStyles();
  const slug = data.get('slug');
  const title = data.get('title');
  const pic = data.get('pic');
  return (
    <>
      <a href={`/topics/${slug}`} rel='noopener noreferrer'>
        <div
          className={classNames(classes.root)}
          style={{ backgroundImage: `url(${pic})` }}
        />
      </a>
      <h3 className={classNames(classes.title)}>
        <a href={`/topics/${slug}`} rel='noopener noreferrer'>
          {title} &gt;&gt;
        </a>
      </h3>
    </>
  );
};

Recommend.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};


export default Recommend;
