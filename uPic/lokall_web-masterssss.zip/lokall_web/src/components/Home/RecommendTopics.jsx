import React from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import PropTypes from 'prop-types';

import ModuleTitle from '@Components/Base/ModuleTitle';
import css from '@Assets/sass/custom.sass';
import Recommend from './Recommend';


const useStyles = createUseStyles(({
  root: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
}), {
  name: 'MayLike',
});

const MayLike = ({ data }) => {
  const classes = useStyles();
  return (
    <>
      <ModuleTitle
        src={require('../../assets/images/like-icon@2x.png')}
        text='Themen, die Ihnen gefallen könnten'
      />
      <div className={classNames(classes.root, css.columns)}>
        {!!data && data.map(item => (
          <div
            className={classNames(css.column, css['is-one-third-desktop'], css['is-half-tablet'], classes.item)}
            key={item.get('id')}
          >
            <Recommend data={item} />
          </div>
        ))}
      </div>
    </>
  );
};

MayLike.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};


export default MayLike;
