import React, { useEffect, useState } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';
import { createUseStyles } from 'react-jss';
import { useDispatch, useSelector, shallowEqual } from 'react-redux';

import HomeAction from '@Actions/home';

import css from '@Assets/sass/custom.sass';


const useStyles = createUseStyles(({
  root: {
    paddingBottom: 26,
  },
  active: {
    backgroundColor: '#e6e6e6',
    color: '#515151',
    borderColor: '#e6e6e6',
    pointerEvents: 'none',
  },
}), {
  name: 'Category',
});

const Category = ({ data }) => {
  const classes = useStyles();
  const [categoryId, setCategoryId] = useState(0);
  const dispatch = useDispatch();
  const homeLoading = useSelector(state => state.getIn(['home', 'loading']), shallowEqual);

  const handelChangeCategory = id => {
    if (!homeLoading) {
      setCategoryId(id);
    }
  };

  useEffect(() => {
    dispatch(HomeAction.fetchHomeData(categoryId));
  }, [categoryId]);

  return (
    <div className={classNames(css.buttons, classes.root)}>
      <button
        type='button'
        className={classNames(css.button, categoryId === 0 && classes.active)}
      >
        Alle
      </button>
      {!!data && data.map(item => {
        const name = item.get('name');
        const id = item.get('id');
        return (
          <button
            type='button'
            className={classNames(css.button, categoryId === id && classes.active)}
            key={name}
            onClick={() => handelChangeCategory(id)}
          >
            {name}
          </button>
        );
      })}
    </div>
  );
};

Category.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};

export default Category;
