import React from 'react';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import { useSelector, shallowEqual } from 'react-redux';

const useStyles = createUseStyles(({
  root: {
    boxSizing: 'border-box',
    padding: [48, 0],
    backgroundColor: '#333333',
  },
  links: {
    listStyleType: 'none',
    textAlign: 'center',
  },
  linkItem: {
    display: 'inline-block',
    margin: [8, 16],

    '& > a': {
      fontSize: 18,
      lineHeight: '22px',
      color: '#ffffff',
    },
  },
  buttons: {
    paddingTop: 24,
    display: 'flex',
    justifyContent: 'center',
  },
  button: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    outline: 'transparent',
    border: 'none',
    overflow: 'hidden',
    backgroundColor: 'transparent',
    cursor: 'pointer',
    padding: 0,
    '& + &': {
      marginLeft: 24,
    },
    '& > img': {
      width: 40,
    },
  },
}), {
  name: 'Footer',
});

const Footer = () => {
  const classes = useStyles();
  const { seoData } = useSelector(state => ({
    seoData: state.getIn(['home', 'seoData']),
  }), shallowEqual);

  return (
    <footer className={classNames(classes.root)}>
      <ul className={classNames(classes.links)}>
        <li className={classNames(classes.linkItem)}>
          <a className={classNames(classes.button)} href='/about' target='_blank' rel='noopener noreferrer'>
            ÜBER UNS
          </a>
        </li>
        <li className={classNames(classes.linkItem)}>
          <a className={classNames(classes.button)} href='/terms' target='_blank' rel='noopener noreferrer'>
            NUTZUNGSBEDINUNGEN
          </a>
        </li>
        <li className={classNames(classes.linkItem)}>
          <a className={classNames(classes.button)} href='/privacy-policy' target='_blank' rel='noopener noreferrer'>
          DATENSCHUTZ
          </a>
        </li>
      </ul>
      <div className={classNames(classes.buttons)}>
        <a
          className={classNames(classes.button)}
          href={seoData.get('facebook')}
          target='_blank'
          rel='noopener noreferrer'
        >
          <img alt='facebook' src={require('../../assets/images/facebook-icon@2x.png')} />
        </a>
        <a
          className={classNames(classes.button)}
          href={seoData.get('twitter')}
          target='_blank'
          rel='noopener noreferrer'
        >
          <img alt='twitter' src={require('../../assets/images/twitter-icon@2x.png')} />
        </a>
        <a
          className={classNames(classes.button)}
          href={seoData.get('google')}
          target='_blank'
          rel='noopener noreferrer'
        >
          <img alt='google' src={require('../../assets/images/google-icon@2x.png')} />
        </a>
      </div>
    </footer>
  );
};

export default Footer;
