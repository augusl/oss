import React, { useEffect, useState } from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';

import css from '@Assets/sass/custom.sass';
import Loading from '@Components/Base/Loading';
import ViewMore from '@Components/Base/ViewMore';
import SearchAction from '@Actions/search';
import Topic from '@Components/Base/Topic';

const useStyles = createUseStyles(({
  root: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
}), {
  name: 'SearchTopics',
});


const SearchTopics = () => {
  const classes = useStyles();
  const [page, setPage] = useState(1);
  const dispatch = useDispatch();
  const { searchData, topic, loading } = useSelector(state => ({
    searchData: state.getIn(['search', 'searchData']),
    topic: state.getIn(['search', 'topic']),
    loading: state.getIn(['search', 'loading']),
  }), shallowEqual);

  const data = topic.get('data');
  const currentPage = topic.get('current_page');
  const lastPage = topic.get('last_page');
  const pageSize = topic.get('per_page');

  useEffect(() => {
    if (page !== 1) {
      dispatch(SearchAction.fetchData({
        keywords: searchData,
        search_type: 'TOPIC',
        page,
        page_size: pageSize,
      }));
    }
  }, [page]);

  useEffect(() => {
    setPage(1);
    dispatch(SearchAction.clearData('TOPIC'));
    dispatch(SearchAction.fetchData({
      keywords: searchData,
      search_type: 'TOPIC',
      page: 1,
      page_size: 10,
    }));
  }, [searchData]);

  useEffect(() => () => {
    dispatch(SearchAction.clearData('TOPIC'));
  }, []);

  const handleChangeCurrentPage = () => {
    if (!loading) {
      setPage(page + 1);
    }
  };

  const statusElement = () => {
    if (loading) {
      return <Loading />;
    }

    if (currentPage === lastPage) {
      return null;
    }

    return <ViewMore onClick={() => handleChangeCurrentPage()} />;
  };

  return (
    <>
      <div className={classNames(css.columns, classes.root)}>
        {!!data && data.map(item => (
          <div
            className={classNames(css.column, css['is-half-tablet'], classes.item)}
            key={String(item.get('id'))}
          >
            <Topic data={item} />
          </div>
        ))}
      </div>
      {statusElement()}
    </>
  );
};

export default SearchTopics;
