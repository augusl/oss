export default (arr = []) => arr.filter((item, index, temp) => temp.indexOf(item, 0) === index);
