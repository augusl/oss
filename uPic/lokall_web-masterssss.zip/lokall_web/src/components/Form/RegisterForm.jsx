import React from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import { useDispatch } from 'react-redux';

import css from '@Assets/sass/custom.sass';

import SignAction from '@Actions/sign';

const useStyles = createUseStyles(({
  columns: {
    width: '100%',
    margin: [0, 'auto'],
  },
  logo: {
    display: 'block',
    margin: [6, 'auto', 20],
    height: 46,
  },
  subTitle: {
    maxWidth: 362,
    fontSize: 21,
    lineHeight: '25px',
    color: '#666666',
    textAlign: 'center',
    marginBottom: 24,
    margin: [0, 'auto'],
  },
  field: {
    '&:not(:last-child)': {
      marginBottom: 18,
    },
  },
  label: {
    textAlign: 'left',
    marginBottom: 6,
  },
  submit: {
    marginTop: 30,
  },
  icon: {
    '&:first-child:not(:last-child)': {
      marginRight: '12px !important',
    },
  },
  twitter: {
    backgroundColor: '#1A2447',
    borderRadius: '#1A2447',
    color: '#ffffff',
  },
  agree: {
    display: 'flex',
    fontSize: '0.875rem',
    alignItems: 'flex-start',
    color: '#929292',
    '& > input': {
      position: 'relative',
      top: 1,
      marginRight: 8,
    },
    '& a': {
      color: '#00BF9A',
      textDecoration: 'underline',
      '&:hover': {
        textDecoration: 'underline',
      },
    },
  },
}), {
  name: 'RegisterForm',
});

const RegisterForm = ({ children }) => {
  const classes = useStyles();
  const dispatch = useDispatch();

  const {
    values,
    handleSubmit,
    handleChange,
    isSubmitting,
    errors: formikErrors,
    touched,
  } = useFormik({
    initialValues: {
      email: '',
      password: '',
      name: '',
      agree: '',
    },
    validate: formData => {
      const error = {};
      if (!formData.email) {
        error.email = 'Das E-Mail-Feld ist erforderlich.';
      }
      if (!formData.password) {
        error.password = 'Das Passwortfeld ist erforderlich.';
      }
      if (!formData.name) {
        error.name = 'The name field is required.';
      }
      if (!formData.agree) {
        error.agree = 'Please agree the terms';
      }
      return error;
    },
    onSubmit: (formData, formikBag) => {
      dispatch(SignAction.signup(formData, formikBag));
    },
    displayName: 'SignUpForm',
  });

  const showError = field => {
    if (touched[field] && formikErrors[field]) {
      return (
        <p className={classNames(css.help, css['is-danger'])}>{formikErrors[field]}</p>
      );
    }
    return null;
  };

  return (
    <>
      <img
        className={classNames(classes.logo)}
        src={require('../../assets/images/logo@2x.png')}
        alt='lokall'
      />
      <p className={classNames(classes.subTitle)}>A place to shark konwledge and better understand the world</p>
      <div className={classNames(css.columns, classes.columns)}>
        <div className={classNames(css.column)}>
          <form autoComplete='off' onSubmit={handleSubmit}>
            <div className={classNames(css.field, css['is-vertical'], classes.field)}>
              <div className={classNames(css['field-label'], css['is-medium'], classes.label)}>
                <label className={classNames(css.label)}>Name:</label>
              </div>
              <div className={classNames(css['field-body'])}>
                <div className={classNames(css.field)}>
                  <div className={classNames(css.control)}>
                    <input
                      name='name'
                      className={classNames(css.input, css['is-medium'])}
                      value={values.name}
                      onChange={handleChange}
                    />
                  </div>
                  {showError('name')}
                </div>
              </div>
            </div>
            <div className={classNames(css.field, css['is-vertical'], classes.field)}>
              <div className={classNames(css['field-label'], css['is-medium'], classes.label)}>
                <label className={classNames(css.label)}>Email:</label>
              </div>
              <div className={classNames(css['field-body'])}>
                <div className={classNames(css.field)}>
                  <div className={classNames(css.control)}>
                    <input
                      name='email'
                      className={classNames(css.input, css['is-medium'])}
                      type='email'
                      value={values.email}
                      onChange={handleChange}
                    />
                  </div>
                  {showError('email')}
                </div>
              </div>
            </div>
            <div className={classNames(css.field, css['is-vertical'], classes.field)}>
              <div className={classNames(css['field-label'], css['is-medium'], classes.label)}>
                <label className={classNames(css.label)}>Passwort:</label>
              </div>
              <div className={classNames(css['field-body'])}>
                <div className={classNames(css.field)}>
                  <div className={classNames(css.control)}>
                    <input
                      name='password'
                      className={classNames(css.input, css['is-medium'])}
                      type='password'
                      value={values.password}
                      onChange={handleChange}
                    />
                  </div>
                  {showError('password')}
                </div>
              </div>
            </div>
            <div className={classNames(css.field, classes.field)}>
              <div className={classNames(css.control)}>
                <label className={classNames(css.checkbox, classes.agree)}>
                  <input type='checkbox' name='agree' value={values.agree} onChange={handleChange} />
                  <span>Mit Ihrer Anmeldung geben Sie an, dass Sie die Nutzungsbedingungen gelesen haben und damit einverstanden sind
                    <a
                      href='/terms'
                      target='_blank'
                    >
                      NUTZUNGSBEDINUNGEN
                    </a>
                    <> und </>
                    <a
                      href='/privacy-policy'
                      target='_blank'
                    >
                      DATENSCHUTZ.
                    </a>
                  </span>
                </label>
              </div>
              {showError('agree')}
            </div>
            <div className={classNames(css.field, classes.field)}>
              <div className={classNames(css.control)}>
                <button
                  type='submit'
                  className={classNames({
                    [css.button]: true,
                    [css['is-fullwidth']]: true,
                    [css['is-medium']]: true,
                    [css['is-primary']]: true,
                    [css['is-rounded']]: true,
                    [css['is-loading']]: isSubmitting,
                  })}
                >
                  Anmelden
                </button>
              </div>
            </div>
          </form>
          {children}
        </div>
      </div>
    </>
  );
};

RegisterForm.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
    PropTypes.string,
  ]).isRequired,
};

export default RegisterForm;
