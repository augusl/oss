import React, { useRef, useState, useEffect } from 'react';
import classNames from 'classnames';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';
import Router, { useRouter } from 'next/router';
import { createUseStyles } from 'react-jss';
import Link from 'next/link';
import Icon from '@mdi/react';
import { mdiLogoutVariant } from '@mdi/js';

import SearchAction from '@Actions/search';
import UiAction from '@Actions/ui';
import SignAction from '@Actions/sign';
import css from '@Assets/sass/custom.sass';

const useStyles = createUseStyles(({
  avatar: {
    display: 'flex',
    alignItems: 'center',
    '& > img': {
      width: 36,
      borderRadius: '50%',
    },
  },
}), {
  name: 'Header',
});


const Header = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const router = useRouter();
  const [isActive, setIsActive] = useState(false);
  const searchRef = useRef(null);

  const user = useSelector(state => state.getIn(['account', 'user']), shallowEqual);

  const name = user.get('name');
  const avatar = user.get('avatar');

  const handleShowModal = type => dispatch(UiAction.showModal(type));

  const handleShowAddTopic = () => {
    if (name) {
      return dispatch(UiAction.showModal('topic'));
    }
    return dispatch(UiAction.showModal('login'));
  };

  const searchListener = () => {
    const targetValue = searchRef.current.value;
    dispatch(SearchAction.setSearchData(targetValue));
    if (global.window.location.href.indexOf('/search') === -1) {
      Router.push('/search/shares');
    }
    searchRef.current.blur();
  };

  const handleEnter = e => {
    if (e.keyCode === 13) {
      searchListener();
    }
  };

  useEffect(() => {
    setIsActive(false);
  }, [router]);

  useEffect(() => {
    searchRef.current.addEventListener('keypress', handleEnter);
    return () => {
      searchRef.current.removeEventListener('keypress', handleEnter);
    };
  }, [searchRef.current]);

  return (
    <nav className={classNames(css.navbar, css['has-shadow'])}>
      <div className={classNames(css.container)}>
        <div className={classNames(css['navbar-brand'])}>
          <a className={classNames(css['navbar-item'])} href='/'>
            <img src={require('@Assets/images/logo@2x.png')} alt='lokall' />
          </a>
          <a
            className={classNames(css['navbar-burger'], css.burger, isActive && css['is-active'])}
            onClick={() => setIsActive(!isActive)}
          >
            <span />
            <span />
            <span />
          </a>
        </div>
        <div className={classNames(css['navbar-menu'], isActive && css['is-active'])}>
          {/* start */}
          <div className={classNames(css['navbar-start'])}>
            {!['/signin', '/signup'].includes(router.pathname) && (
            <div className={classNames(css['navbar-item'])}>
              <button
                className={classNames(css.button, css['is-primary'])}
                type='button'
                onClick={handleShowAddTopic}
              >
                Erstellen Sie ein Thema
              </button>
            </div>
            )}
          </div>
          {/* /start */}
          {/* end */}
          <div className={classNames(css['navbar-end'])}>
            <div className={classNames(css['navbar-item'])}>
              <div className={classNames(css.control, css['has-icons-left'])}>
                <input
                  type='search'
                  className={classNames(css.input, css['is-rounded'])}
                  placeholder='Suche'
                  ref={searchRef}
                />
                <span className={classNames(css.icon, css['is-medium'], css['is-left'])}>
                  <svg viewBox='0 0 1024 1024' width='18px'>
                    <path
                      // eslint-disable-next-line max-len
                      d='M400.696889 801.393778A400.668444 400.668444 0 1 1 400.696889 0a400.668444 400.668444 0 0 1 0 801.393778z m0-89.031111a311.637333 311.637333 0 1 0 0-623.331556 311.637333 311.637333 0 0 0 0 623.331556zM667.904 601.998222l314.766222 314.823111-62.919111 62.976-314.823111-314.823111z'
                      fill='currentColor'
                    />
                  </svg>
                </span>
              </div>
            </div>
            {name ? (
              <div className={classNames(css['navbar-item'], css['has-dropdown'], css['is-hoverable'])}>
                <a className={classNames(css['navbar-link'], classes.avatar)}>
                  <img src={avatar} alt='Benutzerbild' />
                </a>
                <div className={classNames(css['navbar-dropdown'], css['is-right'])}>
                  <Link href='/account/[pageType]' as='/account/topics'>
                    <a className={classNames(css['navbar-item'])}>
                      Meine Themen
                    </a>
                  </Link>
                  <Link href='/account/[pageType]' as='/account/shares'>
                    <a className={classNames(css['navbar-item'])}>
                     Meine Teilen
                    </a>
                  </Link>
                  <Link href='/account/[pageType]' as='/account/favorites'>
                    <a className={classNames(css['navbar-item'])}>
                    Mein Favorit
                    </a>
                  </Link>
                  <Link href='/account/[pageType]' as='/account/notification'>
                    <a className={classNames(css['navbar-item'])}>
                     Benachrichtigung
                    </a>
                  </Link>
                  <hr className={classNames(css['navbar-divider'])} />
                  <a className={classNames(css['navbar-item'], classes.navItem)} onClick={() => dispatch(SignAction.logout())}>
                    <span style={{ marginRight: 8 }}>
                      <Icon path={mdiLogoutVariant} size={0.75} style={{ marginLeft: -3 }} />
                    </span>
                    <span>Ausloggen</span>
                  </a>
                </div>
              </div>
            ) : (
              <>
                {!['/signin', '/signup'].includes(router.pathname) && (
                <div className={classNames(css['navbar-item'])}>
                  <div className={classNames(css.field, css['is-grouped'])}>
                    <div className={classNames(css.control)}>
                      <button
                        className={classNames(css.button, css['is-light'])}
                        type='button'
                        onClick={() => handleShowModal('login')}
                      >
                        Einloggen
                      </button>
                    </div>
                    <div className={classNames(css.control)}>
                      <button
                        className={classNames(css.button, css['is-primary'])}
                        type='button'
                        onClick={() => handleShowModal('register')}
                      >
                        Anmelden
                      </button>
                    </div>
                  </div>
                </div>
                )}
              </>
            )}
          </div>
          {/* /end */}
        </div>
      </div>
    </nav>
  );
};

export default Header;
