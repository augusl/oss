import React, { useState, useEffect } from 'react';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';

import css from '@Assets/sass/custom.sass';
import Loading from '@Components/Base/Loading';
import ViewMore from '@Components/Base/ViewMore';
import Topic from '@Components/Base/Topic';
import AccountAction from '@Actions/account';
import unique from '@Utils/unique';

const useStyles = createUseStyles(({
  root: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
}), {
  name: 'Account-Favorite',
});


const Favorite = () => {
  const classes = useStyles();
  const [page, setPage] = useState(1);
  const dispatch = useDispatch();
  const { favorite, loading } = useSelector(state => ({
    favorite: state.getIn(['account', 'favorite']),
    loading: state.getIn(['account', 'loading']),
  }), shallowEqual);
  const data = unique(favorite.get('data'));
  const currentPage = favorite.get('current_page');
  const lastPage = favorite.get('last_page');
  const pageSize = favorite.get('per_page');

  useEffect(() => {
    if (page !== 1) {
      dispatch(AccountAction.fetchData({
        type: 'FAVORITE',
        page,
        page_size: pageSize,
      }));
    }
  }, [page]);

  const handleChangeCurrentPage = () => {
    if (!loading) {
      setPage(page + 1);
    }
  };

  useEffect(() => () => {
    dispatch(AccountAction.clearData('FAVORITE'));
  }, []);

  const statusElement = () => {
    if (loading) {
      return <Loading />;
    }
    if (currentPage === lastPage) {
      return null;
    }
    return <ViewMore onClick={() => handleChangeCurrentPage()} />;
  };

  return (
    <>
      <div className={classNames(css.columns, classes.root)}>
        {!!data && data.map(item => (
          <div
            className={classNames(css.column, css['is-one-third-desktop'], css['is-half-tablet'], classes.item)}
            key={String(item.get('id'))}
          >
            <Topic data={item} />
          </div>
        ))}
      </div>
      {statusElement()}
    </>
  );
};

export default Favorite;
