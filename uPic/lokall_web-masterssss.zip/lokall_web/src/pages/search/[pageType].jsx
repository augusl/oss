import React from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import { useRouter } from 'next/router';
import Link from 'next/link';

import SearchTopic from '@Components/Search/Topics';
import SearchShares from '@Components/Search/Shares';
import css from '@Assets/sass/custom.sass';

const useStyles = createUseStyles(({
  tab: {
    display: 'flex',
    justifyContent: 'center',
    listStyleType: 'none',
    fontSize: 22,
    lineHeight: '26px',
    paddingTop: 45,
    fontWeight: 700,
    borderBottom: '1px solid #d8d8d8',
  },
  tabItem: {
    fontSize: '18',
    cursor: 'pointer',
    padding: 8,
    margin: [0, 24],
    position: 'relative',
    display: 'flex',
    alignItems: 'center',

    '& > img': {
      marginRight: 10,
      width: 28,
    },
  },
  active: {
    color: '#00BF9A',
    '&:before': {
      content: '""',
      width: '100%',
      height: 4,
      backgroundColor: '#00BF9A',
      position: 'absolute',
      left: 0,
      bottom: 0,
    },
  },
}), {
  name: 'SearchPage',
});

const SearchPage = () => {
  const classes = useStyles();
  const { query: { pageType } } = useRouter();

  return (
    <>
      <ul className={classNames(classes.tab)}>
        <Link href='/search/[pageType]' as='/search/topics'>
          <li className={classNames({ [classes.tabItem]: true, [classes.active]: pageType === 'topics' })}>
            <img src={require('../../assets/images/topic-icon@2x.png')} alt='topics' />
            Thema
          </li>
        </Link>
        <Link href='/search/[pageType]' as='/search/shares'>
          <li className={classNames({ [classes.tabItem]: true, [classes.active]: pageType === 'shares' })}>
            <img src={require('../../assets/images/share-icon@2x.png')} alt='topics' />
            Share
          </li>
        </Link>
      </ul>
      <div className={classNames(css.section, css.container)}>
        { pageType === 'topics' ? <SearchTopic /> : <SearchShares />}
      </div>
    </>
  );
};

export default SearchPage;
