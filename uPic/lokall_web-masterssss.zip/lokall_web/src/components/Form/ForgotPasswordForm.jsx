import React, { useEffect, useRef, useState } from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';

import css from '@Assets/sass/custom.sass';


import SignAction from '@Actions/sign';
import Network from '@Utils/network';
import Config from '@Config';

import { useDispatch } from 'react-redux';

const useStyles = createUseStyles(({
  columns: {
    width: '100%',
    margin: [0, 'auto'],
  },
  logo: {
    display: 'block',
    margin: [6, 'auto', 20],
    height: 46,
  },
  subTitle: {
    maxWidth: 362,
    fontSize: 21,
    lineHeight: '25px',
    color: '#666666',
    textAlign: 'center',
    marginBottom: 24,
    margin: [0, 'auto'],
  },
  field: {
    '&:not(:last-child)': {
      marginBottom: 20,
    },
  },
  label: {
    textAlign: 'left',
    marginBottom: 6,
  },
  submit: {
    marginTop: 30,
  },
  control: {
    display: 'flex',
    '& > div': {
      flex: 1,
      marginRight: 20,
    },
  },
  send: {
    minWidth: 146,
  },
}), {
  name: 'ForgotPasswordForm',
});

const ForgotPasswordForm = ({ children }) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const timeId = useRef(null);
  const [disabled, setDisabled] = useState(false);
  const [time, setTime] = useState(60);
  const [btnContent, setBtnContent] = useState('Send');

  useEffect(() => {
    clearInterval(timeId.current);
  }, []);

  useEffect(() => {
    if (time > 0 && time < 60) {
      setBtnContent(`Resend ${time}s`);
    } else {
      clearInterval(timeId.current);
      setDisabled(false);
      setTime(60);
      setBtnContent('Send');
    }
  }, [time]);

  const {
    values,
    handleSubmit,
    handleChange,
    isSubmitting,
    errors: formikErrors,
    setFieldError,
    touched,
    setTouched,
  } = useFormik({
    initialValues: {
      email: '',
      password: '',
      verification_code: '',
    },
    validate: formData => {
      const error = {};
      if (!formData.email) {
        error.email = 'Das E-Mail-Feld ist erforderlich.';
      }
      if (!formData.verification_code) {
        error.password = 'Das Feld Bestätigungscode ist erforderlich.';
      }

      if (!formData.password) {
        error.password = 'Das Passwortfeld ist erforderlich.';
      }
      return error;
    },
    onSubmit: (formData, formikBag) => {
      dispatch(SignAction.forgetPassword(formData, formikBag));
    },
    displayName: 'ForgetPassword',
  });

  const showError = field => {
    if (touched[field] && formikErrors[field]) {
      return (
        <p className={classNames(css.help, css['is-danger'])}>{formikErrors[field]}</p>
      );
    }
    return null;
  };

  const handleSendEmail = () => {
    setDisabled(true);
    Network.post(`${Config.apiBaseUrl}/api/v1/user/send-code`, {
      email: values.email,
    }).then(() => {
      timeId.current = setInterval(() => setTime(t => t - 1), 1000);
      setDisabled(true);
    }).catch(error => {
      const err = JSON.parse(error.message);
      setDisabled(false);

      Object.keys(err).forEach(item => {
        setTouched({ [item]: true });
        setFieldError(item, err[item][0]);
      });
    });
  };

  return (
    <>
      <img
        className={classNames(classes.logo)}
        src={require('../../assets/images/logo@2x.png')}
        alt='lokall'
      />
      <p className={classNames(classes.subTitle)}>A place to shark konwledge and better understand the world</p>
      <div className={classNames(css.columns, classes.columns)}>
        <div className={classNames(css.column)}>
          <form autoComplete='off' onSubmit={handleSubmit}>
            <div className={classNames(css.field, classes.field)}>
              <div className={classNames(css['field-label'], css['is-medium'], classes.label)}>
                <label className={classNames(css.label)}>Email:</label>
              </div>
              <div className={classNames(css['field-body'])}>
                <div className={classNames(css.field)}>
                  <div className={classNames(css.control)}>
                    <input
                      name='email'
                      className={classNames(css.input, css['is-medium'])}
                      type='email'
                      value={values.email}
                      onChange={handleChange}
                    />
                  </div>
                  {showError('email')}
                </div>
              </div>
            </div>
            <div className={classNames(css.field, classes.field)}>
              <div className={classNames(css['field-label'], css['is-medium'], classes.label)}>
                <label className={classNames(css.label)}>Code:</label>
              </div>
              <div className={classNames(css['field-body'])}>
                <div className={classNames(css.field)}>
                  <div className={classNames(css.control, classes.control)}>
                    <input
                      className={classNames(css.input, css['is-medium'])}
                      name='verification_code'
                      value={values.verification_code}
                      onChange={handleChange}
                      style={{ flex: 1, marginRight: 16 }}
                    />
                    <button
                      type='button'
                      className={classNames(css.button, css['is-medium'], css['is-link'], classes.send)}
                      disabled={disabled}
                      onClick={handleSendEmail}
                    >
                      {btnContent}
                    </button>
                  </div>
                  {showError('verification_code')}
                </div>
              </div>
            </div>
            <div className={classNames(css.field, classes.field)}>
              <div className={classNames(css['field-label'], css['is-medium'], classes.label)}>
                <label className={classNames(css.label)}>Passwort:</label>
              </div>
              <div className={classNames(css['field-body'])}>
                <div className={classNames(css.field)}>
                  <div className={classNames(css.control)}>
                    <input
                      name='password'
                      className={classNames(css.input, css['is-medium'])}
                      type='password'
                      value={values.password}
                      onChange={handleChange}
                    />
                  </div>
                  {showError('password')}
                </div>
              </div>
            </div>
            <div className={classNames(css.field, classes.field)}>
              <div className={classNames(css.control)}>
                <button
                  type='submit'
                  className={classNames({
                    [classes.submit]: true,
                    [css.button]: true,
                    [css['is-fullwidth']]: true,
                    [css['is-medium']]: true,
                    [css['is-primary']]: true,
                    [css['is-rounded']]: true,
                    [css['is-loading']]: isSubmitting,
                  })}
                >
                  Einreichen
                </button>
              </div>
            </div>
          </form>
          {children}
        </div>
      </div>
    </>
  );
};


ForgotPasswordForm.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
    PropTypes.string,
  ]).isRequired,
};

export default ForgotPasswordForm;
