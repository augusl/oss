import React from 'react';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import PropTypes from 'prop-types';

const useStyles = createUseStyles(({
  root: {
    display: 'flex',
    alignItems: 'center',
    fontSize: 28,
    lineHeight: '34px',
    color: '#2c2c2c',
    marginBottom: 20,
    marginTop: 30,
    fontWeight: 700,
    '& > img': {
      width: 28,
      height: 28,
      marginRight: 10,
    },
  },
}), {
  name: 'ModuleTitle',
});

const ModuleTitle = ({ src, text }) => {
  const classes = useStyles();
  return (
    <h2
      className={classNames({
        [classes.root]: true,
      })}
    >
      <img src={src} alt={text} />
      {text}
    </h2>
  );
};

ModuleTitle.propTypes = {
  src: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
};


export default ModuleTitle;
