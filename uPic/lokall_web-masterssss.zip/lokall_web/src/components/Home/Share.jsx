import React from 'react';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import PropTypes from 'prop-types';

const useStyles = createUseStyles(({
  root: {
    borderRadius: 7,
    overflow: 'hidden',
    backgroundColor: '#ffffff',
    boxShadow: '0px 2px 10px 0px rgba(0, 0, 0, 0.2)',
    height: '100%',
  },
  pic: {
    width: '100%',
    paddingTop: '54%',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
  },
  content: {
    padding: [15, 20],
  },
  title: {
    fontSize: 20,
    lineHeight: '28px',
    color: '#333333',
    minHeight: 84,
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 3,
  },
  desc: {
    fontSize: 16,
    lineHeight: '21px',
    color: '#5e5f79',
    minHeight: 84,
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 4,
  },
  box: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: 14,
    lineHeight: '17px',
    margin: [14, 0],
    color: '#5e5f79',
  },
  link: {
    marginLeft: '0.5em',
    flex: 1,
    display: '-webkit-box',
    overflow: 'hidden',
    WebkitBoxOrient: 'vertical',
    WebkitLineClamp: 1,
    color: '#333333',
  },
  line: {
    width: 1,
    height: 14,
    flexShrink: 0,
    backgroundColor: '#333333',
    margin: [0, '1em'],
  },
}), {
  name: 'Share',
});

const Share = ({ data }) => {
  const classes = useStyles();
  const title = data.get('title');
  const description = data.get('description');
  const pic = data.get('pic');
  const fromUrl = data.get('from_url');
  const createdAt = data.get('created_at');
  const showUrl = data.get('show_url');

  return (
    <div className={classNames(classes.root)}>
      <a
        href={fromUrl}
        target='_blank'
        rel='noreferrer'
      >
        <div
          className={classNames(classes.pic)}
          style={{ backgroundImage: `url(${pic})` }}
        />
      </a>
      <div className={classNames(classes.content)}>
        <h3 className={classNames(classes.title)}>
          <a
            href={fromUrl}
            target='_blank'
            rel='noreferrer'
          >
            {title}
          </a>
        </h3>
        <div className={classNames(classes.box)}>
          Von
          <a
            href={fromUrl}
            target='_blank'
            rel='noreferrer'
            className={classNames(classes.link)}
          >
            {showUrl}
          </a>
          <div className={classNames(classes.line)} />
          <div>{createdAt}</div>
        </div>
        <p className={classNames(classes.desc)}>{description}</p>
      </div>
    </div>
  );
};

Share.propTypes = {
  data: PropTypes.instanceOf(Object).isRequired,
};


export default Share;
