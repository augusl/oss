import React, { useEffect, useState } from 'react';
import classNames from 'classnames';
import { createUseStyles } from 'react-jss';
import ReactSelect from 'react-select';
import { useFormik } from 'formik';
import { useDispatch, useSelector, shallowEqual } from 'react-redux';
import { useRouter } from 'next/router';

import css from '@Assets/sass/custom.sass';

import CategoryAction from '@Actions/category';
import AddAction from '@Actions/add';
import ToastAction from '@Actions/toast';
import Upload from '@Components/Base/Upload';


import netWork from '@Utils/network';
import Config from '@Config';


const useStyles = createUseStyles({
  label: {
    textAlign: 'left',
    marginBottom: 8,
    marginnTop: 8,
    fontSize: [21, '!important'],
  },
}, {
  name: 'ContributeForm',
});

const ContributeForm = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const [topicOptions, setTopicOptions] = useState(null);
  const [selectedTopicId, setSelectedTopicId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [picUrl, setPicUrl] = useState('');
  const router = useRouter();

  const {
    topics,
  } = useSelector(state => ({
    topics: state.getIn(['category', 'topics']),
  }), shallowEqual);

  useEffect(() => {
    dispatch(CategoryAction.fetchTopic());
  }, []);

  const {
    values,
    handleSubmit,
    handleChange,
    isSubmitting,
    errors: formikErrors,
    touched,
    setFieldValue,
  } = useFormik({
    initialValues: {
      title: '',
      description: '',
      pic: '',
      topic_id: selectedTopicId || '',
      categorys: '',
      from_url: '',
    },
    onSubmit: (formData, formikBag) => {
      dispatch(AddAction.addContribute(formData, formikBag));
    },
    displayName: 'ContributeForm',
  });

  useEffect(() => {
    if (topics.size) {
      const tempTopics = [];
      if (router.pathname === '/topics/[pageType]') {
        const id = topics.find(item => item.get('slug') === router.query.pageType).get('id');
        setFieldValue('topic_id', id);
        setSelectedTopicId(id);
      }
      topics.map(item => (
        tempTopics.push({
          value: item.get('id'),
          label: item.get('title'),
        })
      ));
      setTopicOptions(tempTopics);
    }
  }, [topics]);

  const customStyle = {
    control: styles => ({ ...styles, minHeight: 48 }),
  };

  const showError = field => {
    if (touched[field] && formikErrors[field]) {
      return (
        <p className={classNames(css.help, css['is-danger'])}>{formikErrors[field]}</p>
      );
    }
    return null;
  };

  const handleChangePic = path => {
    setFieldValue('pic', path);
  };

  const handleChangeTopic = data => {
    setFieldValue('topic_id', data.value);
  };

  const handleFetch = () => {
    if (values.from_url) {
      setLoading(true);
      netWork.post(`${Config.apiBaseUrl}/api/v1/contribute/fetch`, {
        from_url: values.from_url,
      }).then(res => {
        setLoading(false);
        setFieldValue('pic', res.get('pic_path'));
        setFieldValue('title', res.get('title'));
        setFieldValue('description', res.get('description'));
        setPicUrl(res.get('pic_url'));
      }).catch(err => {
        setLoading(false);
        dispatch(ToastAction.openToast(JSON.parse(err.message).from_url, 'danger'));
      });
    }
  };

  return (
    <form autoComplete='off' onSubmit={handleSubmit}>
      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)}>Von Url:</label>
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              <input
                className={classNames(css.input, css['is-medium'])}
                name='from_url'
                autoComplete='off'
                value={values.from_url}
                onChange={handleChange}
              />
            </div>
            {showError('title')}
          </div>
        </div>
      </div>
      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)} />
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              <button
                type='button'
                className={classNames({
                  [css.button]: true,
                  [css['is-primary']]: true,
                  [css['is-loading']]: loading,
                })}
                onClick={handleFetch}
              >
                Holen
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)}>Titel:</label>
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              <input
                className={classNames(css.input, css['is-medium'])}
                name='title'
                value={values.title}
                autoComplete='off'
                onChange={handleChange}
              />
            </div>
            {showError('title')}
          </div>
        </div>
      </div>
      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)}>Thema:</label>
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              {topicOptions && (
                <ReactSelect
                  defaultValue={topicOptions.find(option => option.value === selectedTopicId)}
                  isDisabled={router.pathname === '/topics'}
                  options={topicOptions}
                  styles={customStyle}
                  placeholder='Thema'
                  onChange={handleChangeTopic}
                />
              )}
            </div>
            {showError('topic_id')}
          </div>
        </div>
      </div>
      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)}>Beschreibung:</label>
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              <textarea
                className={classNames(css.textarea, css['is-medium'])}
                name='description'
                value={values.description}
                autoComplete='off'
                onChange={handleChange}
              />
            </div>
            {showError('description')}
          </div>
        </div>
      </div>
      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)}>Foto:</label>
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              <Upload onChange={handleChangePic} src={picUrl} />
            </div>
            {showError('pic')}
          </div>
        </div>
      </div>

      <div className={classNames(css.field)}>
        <div className={classNames(css['field-label'], css['is-normal'])}>
          <label className={classNames(css.label, classes.label)} />
        </div>
        <div className={classNames(css['field-body'])}>
          <div className={classNames(css.field)}>
            <div className={classNames(css.control)}>
              <button
                type='submit'
                className={classNames({
                  [css.button]: true,
                  [css['is-fullwidth']]: true,
                  [css['is-primary']]: true,
                  [css['is-loading']]: isSubmitting,
                })}
              >
                Teilen hinzufügen
              </button>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default ContributeForm;
