/* eslint-disable max-len */
import React, { useEffect, useState } from 'react';
import { useSelector, shallowEqual, useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
import { createUseStyles } from 'react-jss';
import classNames from 'classnames';
import { parseCookies } from 'nookies';
import Head from 'next/head';
import Icon, { Stack } from '@mdi/react';
import { mdiPlus } from '@mdi/js';

import css from '@Assets/sass/custom.sass';

import Loading from '@Components/Base/Loading';
import ViewMore from '@Components/Base/ViewMore';
import Share from '@Components/Base/Share';

import TopicAction from '@Actions/topic';
import UiAction from '@Actions/ui';

const mutilpellipsis = line => ({
  display: '-webkit-box',
  '-webkit-line-clamp': line,
  '-webkit-box-orient': 'vertical',
  overflow: 'hidden',
});

const useStyles = createUseStyles(({
  root: {
    backgroundColor: '#ffffff',
    padding: [32, 12],
    boxShadow: '5px 25px 34px 0px rgba(176,176,176,0.35)',
    marginBottom: 32,
    display: 'flex',
    alignItems: 'center',
  },
  columnRoot: {
    flexWrap: 'wrap',
  },
  item: {
    marginBottom: 26,
  },
  pic: {
    width: 128,
    height: 128,
    objectFit: 'cover',
    borderRadius: 4,
    boxShadow: '0 0 6px rgba(0,0,0,.5)',
  },
  content: {
    flex: 1,
    flexShrink: 0,
    lineHeight: 1.4,
    margin: [0, 24],
    alignSelf: 'center',
  },
  title: {
    margin: 0,
    fontSize: 24,
    ...mutilpellipsis(2),
  },
  desc: {
    margin: 0,
    fontSize: 16,
    ...mutilpellipsis(3),
  },
  link: {
    color: '#00bd97',
    ...mutilpellipsis(1),
  },
  buttons: {
    alignSelf: 'center',
  },
  button: {
    border: 'none',
  },
  section: {
    padding: ['3rem', '1.5rem'],
  },
  '@media screen and (max-width: 768px)': {
    section: {
      padding: ['1.5rem', '1.5rem'],
    },
    root: {
      boxShadow: '0 0 10px 0px rgba(176,176,176,0.35)',
      marginBottom: 20,
      padding: [16, 12],
    },
    pic: {
      width: 108,
      height: 108,
    },
    content: {
      flex: 1,
      marginRight: 0,
    },
    buttons: {
      display: 'none',
    },
    title: {
      fontSize: 16,
    },
    desc: {
      fontSize: 12,
    },
  },
}), {
  name: 'TopicsPage',
});

const TopicsPage = ({ pageType }) => {
  const [page, setPage] = useState(1);
  const [disabled, setDisabled] = useState(false);
  const dispatch = useDispatch();
  const classes = useStyles();

  const {
    user,
    topicInfo,
    contributes,
    topicLoading,
  } = useSelector(state => ({
    user: state.getIn(['account', 'user']),
    topicLoading: state.getIn(['topic', 'loading']),
    topicInfo: state.getIn(['topic', 'topicInfo']),
    contributes: state.getIn(['topic', 'contributes']),
  }), shallowEqual);

  const data = contributes.get('data');
  const currentPage = contributes.get('current_page');
  const lastPage = contributes.get('last_page');
  const pageSize = contributes.get('per_page');

  useEffect(() => {
    if (page !== 1) {
      dispatch(TopicAction.fetchTopicData({
        slug: pageType,
        page,
        page_size: pageSize,
      }));
    }
  }, [page]);

  useEffect(() => () => {
    dispatch(TopicAction.clearTopicData());
  }, []);

  const handleChangeCurrentPage = () => {
    if (!topicLoading) {
      setPage(page + 1);
    }
  };

  const statusElement = () => {
    if (topicLoading) {
      return <Loading />;
    }
    if (currentPage === lastPage) {
      return null;
    }
    return <ViewMore onClick={() => handleChangeCurrentPage()} />;
  };

  useEffect(() => {
    setDisabled(false);
  }, [topicInfo.get('favorite_status')]);

  const handleShowAddContribute = () => {
    if (!user.get('name')) {
      dispatch(UiAction.showModal('login'));
    } else {
      dispatch(UiAction.showModal('contribute'));
    }
  };

  const handleChangeFavorate = () => {
    if (!user.get('name')) {
      dispatch(UiAction.showModal('login'));
    } else {
      setDisabled(true);
      dispatch(TopicAction.favorate({ topic_id: topicInfo.get('id'), type: Boolean(!topicInfo.get('favorite_status')) }));
    }
  };

  const createTopicInfo = () => {
    if (topicInfo.size) {
      return (
        <div className={classNames(classes.root)}>
          <div className={classNames(css.container)} style={{ display: 'flex' }}>
            <img src={topicInfo.get('pic')} alt='' className={classNames(classes.pic)} />
            <div className={classNames(classes.content)}>
              <h2 className={classNames(classes.title)}>{topicInfo.get('title')}</h2>
              {/* <Link href='/author/[id]' as={`/author/${topicInfo.get('author_id')}`}>
                <a className={classNames(classes.link)}>{topicInfo.get('author')}</a>
              </Link> */}
              <p className={classNames(classes.desc)}>{topicInfo.get('description')}</p>
            </div>
            <div className={classNames(css.buttons, classes.buttons)}>
              <button
                type='button'
                className={classNames(css.button, classes.button)}
                onClick={handleShowAddContribute}
              >
                <span className={classNames(css.icon, css['is-small'])}>
                  <Icon path={mdiPlus} size={1} />
                </span>
              </button>
              <button
                type='button'
                className={classNames(css.button, classes.button, disabled && css['is-loading'])}
                onClick={handleChangeFavorate}
              >
                <span className={classNames(css.icon, css['is-small'])}>
                  {topicInfo.get('favorite_status') ? (
                    <Stack viewBox='0 0 1024 1024' size={1}>
                      <Icon path='M944.255604 353.822604 862.950712 341.403159 785.677421 401.086627 905.261615 419.351878 712.544379 616.887412 700.089602 629.65504 702.964082 647.254039 748.099726 923.895389 514.17897 794.609175 497.086538 785.162403 479.998033 794.609175 246.073349 923.895389 265.870099 802.563747 183.947373 865.838988 171.457252 942.385804C163.811603 988.44295 212.799523 1023.007418 253.730779 1000.404247L497.086538 865.905734 740.434441 1000.396404C781.254435 1023.037533 830.197851 988.497943 822.724985 942.415919L775.580083 653.475537 975.843489 448.206662C1007.600226 415.561123 989.219775 360.750941 944.255604 353.822604L944.255604 353.822604ZM292.82556 694.224849 692.603643 385.453684 769.878242 325.77024 958.773306 179.877213 958.668591 179.743697C959.645077 179.125853 960.601928 178.463535 961.5326 177.744896 977.749336 165.218141 980.742933 141.9173 968.214854 125.699235 955.690701 109.481193 932.387242 106.487599 916.167887 119.014377 915.237215 119.734295 914.354974 120.492195 913.512003 121.278883L913.409904 121.145367 675.707555 304.737815 556.951936 51.720611C536.805693 8.592919 475.201992 8.595526 455.5741 52.166959L333.666499 311.897856 59.247753 353.810828C14.233842 360.572928-4.264415 415.61479 27.642854 448.238057L226.288382 651.849798 32.446746 801.567628 32.470307 801.593786C17.205187 814.30514 14.617367 836.914851 26.858785 852.769001 39.10282 868.616611 61.632682 871.828806 77.787897 860.271965L77.811458 860.298147 210.904145 757.501393 292.82556 694.224849 292.82556 694.224849ZM98.195931 419.353204 362.97155 378.910185 381.611176 376.063185 389.623336 358.993012 506.361844 110.262644 618.411648 348.988602 282.593401 608.362147 98.195931 419.353204 98.195931 419.353204Z' />
                    </Stack>
                  ) : (
                    <Stack viewBox='0 0 1024 1024' size={1}>
                      <Icon path='M573.058008 41.470756l105.724829 222.713318c9.599712 20.99137 28.99113 35.198944 51.134466 38.526845l235.832925 35.710928c55.67833 8.511745 77.885663 79.933602 37.502875 120.764377l-170.490886 174.01078c-15.871524 16.383508-23.295301 39.67881-19.32742 62.910113l40.318791 244.792656c9.727708 57.854264-48.830535 102.076938-98.813036 74.877754l-211.449657-116.220514a65.66203 65.66203 0 0 0-63.102107 0l-210.809675 115.644531c-49.982501 27.199184-107.964761-17.023489-98.877034-74.877754l40.31879-244.792656a72.637821 72.637821 0 0 0-19.32742-62.910113L20.626581 459.762207C-19.692209 418.931432 2.451127 347.509575 58.257452 338.99783l235.832925-35.710929c22.143336-3.391898 41.470756-17.535474 51.134466-38.526844L450.885674 42.046739a66.813996 66.813996 0 0 1 122.172334-0.639981z' />
                    </Stack>
                  )}
                </span>
              </button>
            </div>
          </div>
        </div>
      );
    }
    return <></>;
  };

  return (
    <>
      <Head>
        <title>{topicInfo.get('title')} - lokall.de</title>
        <meta name='keywords' content={topicInfo.get('seo_keywords')} />
        <meta name='description' content={topicInfo.get('seo_description')} />
        <meta
          name='twitter:card'
          content='summary_large_image'
        />
        <meta
          name='twitter:site'
          content='@Lokall.de'
        />
        <meta
          name='twitter:title'
          content={topicInfo.get('title')}
        />
        <meta
          name='twitter:description'
          content={topicInfo.get('seo_description')}
        />
        <meta
          name='twitter:image'
          content={topicInfo.get('pic')}
        />
        <meta
          property='og:url'
          content='https://www.lokall.de'
        />
        <meta
          property='og:title'
          content={topicInfo.get('title')}
        />
        <meta
          property='og:description'
          content={topicInfo.get('seo_description')}
        />
        <meta
          property='og:image'
          content={topicInfo.get('pic')}
        />
        <meta
          property='og:site_name'
          content='Lokall'
        />
      </Head>

      {createTopicInfo()}
      <div className={classNames(css.container, css.section, classes.section)}>
        <div className={classNames(css.columns, classes.columnRoot)}>
          {!!data && data.map(item => (
            <div
              className={classNames(css.column, css['is-half-tablet'], classes.item)}
              key={String(item.get('id'))}
            >
              <Share data={item} />
            </div>
          ))}
        </div>
        {statusElement()}
      </div>
    </>
  );
};

TopicsPage.getInitialProps = async ctx => {
  const { store, query: { pageType } } = ctx;
  const { token } = parseCookies(ctx);
  await store.dispatch(TopicAction.fetchTopicData({
    slug: pageType,
    page: 1,
    page_size: 10,
  }, {
    Authorization: `Bearer ${token}`,
  }));
  return {
    pageType,
    store,
  };
};

TopicsPage.propTypes = {
  pageType: PropTypes.string.isRequired,
};

export default TopicsPage;
